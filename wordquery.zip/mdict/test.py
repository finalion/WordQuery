from mdict_query import IndexBuilder

builder = IndexBuilder(
    u"C:\\Users\\surface\\Documents\\dicts\\ode3-2016\\ode3.mdx")
result_text = builder.mdx_lookup("test")

with open('test.html', 'wb') as f:
    f.write(result_text[0].encode('utf-8'))
# print result_text[0]
