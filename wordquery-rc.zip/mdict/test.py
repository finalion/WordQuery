#-*- coding:utf-8 -*-
import os
from mdict_query import IndexBuilder
builder = IndexBuilder('C:\Users\surface\Documents\dicts\Merriam Webster\'s Collegiate Dictionary and Thesaurus 2015\mwu.mdx')

lst = builder.get_mdd_keys('sp.png')
print lst


# ==> ['/style.css', ...]
bytes_list = builder.mdd_lookup('sp.png')
open('a.png','wb').write(bytes_list[0])

def save_media_files(ib, *args, **kwargs):
    """
    only get the necessary static files
    ** kwargs: data = list
    """
    lst = []
    wild = list(args) + kwargs.get('data', [])
    print wild
    
    for each in wild:
       lst.extend(builder.get_mdd_keys(each))
    print lst
    # media_dir = mw.col.media.dir()
    # for each in lst:
    #     bytes_list = ib.mdd_lookup(each)
    #     if bytes_list:
    #         savepath = os.path.join(media_dir, '_'+os.path.basename(each))
    #         # showInfo(savepath)
    #         if not os.path.exists(savepath): 
    #             with open(savepath, 'wb') as f:
    #                 f.write(bytes_list[0])

